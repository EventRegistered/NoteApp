# Notes Frontend (Refactor)

This frontend uses Vite + React + Tailwind + React Query. Simple, modular structure.

## Quick start
1. `cd frontend`
2. `npm install`
3. `cp .env.example .env` (if needed)
4. `npm run dev`