import React, { useEffect, useRef } from "react";
import Prism from "prismjs";

import "prismjs/components/prism-javascript";
import "prismjs/components/prism-python";
import "prismjs/components/prism-markup";
import "prismjs/themes/prism.css";

export default function CodeBlock({ code, language = "javascript" }) {
  const ref = useRef();

  useEffect(() => {
    Prism.highlightElement(ref.current);
  }, [code, language]);

  return (
    <pre className={`language-${language}`}>
      <code ref={ref} className={`language-${language}`}>
        {code}
      </code>
    </pre>
  );
}
